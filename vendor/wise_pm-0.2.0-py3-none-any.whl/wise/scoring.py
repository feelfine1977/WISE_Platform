"""Phase 2: constraint evaluation and view-specific case scoring (paper Sec. IV-D).

Given an :class:`~wise.log.EventLog` and a :class:`~wise.norm.Norm`, this
module produces

* the violation matrix ``V`` (cases × constraints) with ``ν_c(σ) ∈ [0, 1]``
  and ``NaN`` where the constraint is not applicable (``σ ∉ C_app``) or not
  evaluable (a skipped lag endpoint, a missing metric attribute),
* the applicability-aware case score per view::

      S^(p)(σ) = 1 − Σ_{c∈C_app(σ)} w_c^(p) ν_c(σ) / Σ_{c∈C_app(σ)} w_c^(p)

  (``NaN`` when no positively weighted constraint applies: the case is
  *unscored* and excluded from aggregation), and
* the layer contributions ``Δ_λ^(p)(σ) = Σ_{c∈C_λ} w̃_c,σ ν_c(σ)`` with the
  per-case effective weights ``w̃``, so that ``1 − S = Σ_λ Δ_λ`` exactly.

Two scoring modes exist. ``"layer_balanced"`` (default) first averages the
applicable constraints within each layer with their within-layer weights,
then averages the applicable layers with the layer weights, so that every
applicable layer keeps its full weight. ``"flat"`` renormalises the raw
constraint weights over the applicable set. The two coincide when all
constraints of a layer apply to a case. The mode is part of the norm
(``Norm.scoring_mode``) and can be overridden per call.

A norm is evaluated under its semantics profile (``Norm.semantics``,
:mod:`wise.semantics`), which :func:`score` and :func:`violation_matrix` take
from the norm and hand to every evaluation. Under the corrected profile of
schema version 3 a case whose applicability is unknown (an attribute the rule
reads is missing) has no value for the constraint and is left out of its
denominator, and a ``quantile_scale`` recipe is computed only with a fitted
calibration record.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from ._version import __version__
from .calibration import Calibration
from .constraints import Constraint
from .derive import derived_log, realised_calibrations
from .errors import NormError, NotScoredError
from .family import REASONS, Evaluation, family_of
from .log import EventLog
from .norm import SCORING_MODES, Norm, NormConstraint
from .recipes import QuantileScaleRecipe, Recipe
from .selection import LEGACY, select_cases
from .semantics import LEGACY_SEMANTICS, Semantics


# ------------------------------------------------------------------ signals
def evaluate(constraint: Constraint | NormConstraint, log: EventLog, *, semantics: Semantics = LEGACY_SEMANTICS) -> Evaluation:
    """Evaluate one constraint on every case of ``log``, with the reason per case.

    The constraint's family (:mod:`wise.family`) computes the values. For a
    :class:`~wise.norm.NormConstraint` the result is restricted to its
    applicability, evaluated under the missing-value policy of ``semantics``:
    cases outside it are :data:`~wise.family.OUT_OF_SCOPE`, cases whose scope
    is unknown :data:`~wise.family.SCOPE_UNKNOWN`, and both Series are named
    by the constraint id. A constraint of a norm is evaluated under the norm's
    profile (``norm.semantics``); the default is the 0.1.0 profile.
    """
    if not isinstance(constraint, NormConstraint):
        ev: Evaluation = family_of(constraint).evaluate(constraint, log)
        return ev
    nc = constraint
    try:
        ev = family_of(nc.constraint).evaluate(nc.constraint, log)
    except NormError as exc:
        raise NormError(f"constraint {nc.id!r}: {exc}") from exc
    if nc.applicability:
        if semantics.missing_values == LEGACY:
            ev = ev.within(nc.applies_to(log.cases, log))
        else:
            ev = ev.within(nc.scope(log.cases, log, missing=semantics.missing_values))
    return ev.rename(nc.id)


def evaluate_constraint(log: EventLog, nc: NormConstraint, *, semantics: Semantics = LEGACY_SEMANTICS) -> pd.Series:
    """Evaluate one norm constraint on every case → ``ν_c(σ)``.

    Returns a float Series aligned to ``log.cases``; ``NaN`` marks cases to
    which the constraint does not apply, whose scope is unknown, or on which
    it is not evaluable (:func:`evaluate` gives the reason).
    """
    return evaluate(nc, log, semantics=semantics).value


def violation_matrix(log: EventLog, norm: Norm, *, return_scope: bool = False) -> Any:
    """``V``: cases × constraints (``ν_c(σ)``, NaN if not applicable/evaluable),
    evaluated under the norm's semantics profile (``norm.semantics``).

    With ``return_scope=True`` also return the boolean scope matrix ``S``
    (``σ ∈ C_app``, known to apply), which distinguishes "out of scope" from
    "not evaluable". Neither table carries the reason a case has no value;
    :attr:`ScoreResult.reasons` (from :func:`score`) and :func:`evaluate` do.
    """
    V, S, _ = _evaluate_norm(log, norm)
    return (V, S) if return_scope else V


def _evaluate_norm(log: EventLog, norm: Norm) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Values, scope and reasons (cases × constraints) of every constraint under the norm's profile."""
    semantics = norm.semantics
    cols: dict[str, pd.Series] = {}
    scope: dict[str, pd.Series] = {}
    reasons: dict[str, pd.Series] = {}
    for nc in norm.constraints:
        ev = evaluate(nc, log, semantics=semantics)
        cols[nc.id] = ev.value
        scope[nc.id] = ev.in_scope
        reasons[nc.id] = ev.reason
    index = log.case_ids
    return pd.DataFrame(cols, index=index), pd.DataFrame(scope, index=index), pd.DataFrame(reasons, index=index)


# ------------------------------------------------------------------- scores
@dataclass(eq=False)
class ScoreResult:
    """Output of :func:`score`.

    Attributes
    ----------
    cases
        Case attributes (index = case id), incl. ``exposure`` if provided and
        the norm's derived attributes.
    violations
        ``V`` matrix, NaN where not applicable or not evaluable.
    in_scope
        Boolean cases × constraints: ``σ ∈ C_app`` (scope only; a case whose
        scope is unknown under the three-valued policy is not in scope).
    reasons
        Cases × constraints, why each case has its value or has none: the
        reason codes of :mod:`wise.family` (a categorical column per
        constraint), as :func:`evaluate` gives them. A case with a value has
        :data:`~wise.family.EVALUATED` (:data:`~wise.family.CENSORED` for a
        ``lag`` that scores an open case by its age). A case without one is
        :data:`~wise.family.OUT_OF_SCOPE`, :data:`~wise.family.SCOPE_UNKNOWN`,
        or the family's reason (:data:`~wise.family.MISSING_ANCHOR`,
        :data:`~wise.family.MISSING_ACTIVITY`,
        :data:`~wise.family.MISSING_ATTRIBUTE`,
        :data:`~wise.family.MISSING_ACTIVATION`,
        :data:`~wise.family.MISSING_RESPONSE`, otherwise
        :data:`~wise.family.NOT_EVALUABLE`). Which reasons occur depends on
        the norm's schema version: :data:`~wise.family.SCOPE_UNKNOWN` only
        under schema version 3 (three-valued applicability); under schema
        version 2, the default, a case whose rule reads a missing attribute
        is in scope or :data:`~wise.family.OUT_OF_SCOPE` as in 0.1.0. The
        family reasons are the same under both. ``None`` for a result built
        by hand without them. :meth:`verdicts` writes them out beside the
        values.
    scores
        Cases × views, ``S^(p)(σ)``; NaN = unscored.
    contributions
        ``{view: cases × layers}`` with ``Δ_λ^(p)(σ)``.
    log
        The :class:`EventLog` the norm was evaluated on (for drill-down to
        traces): the scored log itself, or, when the run derived attributes,
        a log that shares its events and adds them.
    calibrations
        Per ``quantile_scale`` recipe computed in the run, the
        :class:`~wise.calibration.Calibration` it divided by: its fitted
        record, or, for a recipe without one (schema version 2 legacy
        profile), the record of the divisor realised on the scored cases,
        stating the scored log's fingerprint. Empty with ``derive=False``.
    mode
        The scoring mode the scores were computed in; defaults to the
        norm's ``scoring_mode``.
    """

    norm: Norm
    cases: pd.DataFrame
    violations: pd.DataFrame
    in_scope: pd.DataFrame
    scores: pd.DataFrame
    contributions: dict[str, pd.DataFrame]
    mode: str | None = None
    log: EventLog | None = field(default=None, repr=False)
    norm_fingerprint: str = ""
    wise_version: str = __version__
    _weights: dict[str, np.ndarray] = field(default_factory=dict, repr=False)
    _eff_cache: dict[str, pd.DataFrame] = field(default_factory=dict, repr=False)
    calibrations: Mapping[str, Calibration] = field(default_factory=dict, kw_only=True)
    reasons: pd.DataFrame | None = field(default=None, kw_only=True)

    def __post_init__(self) -> None:
        if self.mode is None:
            self.mode = self.norm.scoring_mode

    def __repr__(self) -> str:
        return (
            f"ScoreResult({len(self.scores):,} cases × {self.violations.shape[1]} constraints, "
            f"views={self.views}, mode={self.mode!r}, applicability={self.applicability_density():.3f})"
        )

    @property
    def applicable(self) -> pd.DataFrame:
        """Boolean cases × constraints: evaluated (in scope and evaluable)."""
        return self.violations.notna()

    @property
    def views(self) -> list[str]:
        return list(self.scores.columns)

    def effective_weights(self, view: str) -> pd.DataFrame:
        """Per-case effective weights ``w̃_c,σ`` (cases × constraints); rows of
        scored cases sum to 1. A zero weight does not say why the case has no
        value; :attr:`reasons` does."""
        if view not in self._eff_cache:
            M = self.violations.notna().to_numpy(dtype=float)
            w_eff = _effective_weights(M, self._weights[view], self.norm, self.mode or self.norm.scoring_mode)
            self._eff_cache[view] = pd.DataFrame(
                np.nan_to_num(w_eff), index=self.violations.index, columns=self.violations.columns
            )
        return self._eff_cache[view]

    def penalties(self, view: str) -> pd.DataFrame:
        """Per-constraint penalty ``w̃_c,σ ν_c(σ)`` (cases × constraints); sums
        to ``1 − S^(p)(σ)`` per case. A zero penalty does not say why the case
        has no value; :attr:`reasons` does."""
        return self.effective_weights(view) * self.violations.fillna(0.0)

    def frame(self, view: str | None = None) -> pd.DataFrame:
        """Wide per-case table for aggregation and drill-down.

        Columns: case attributes, ``exposure`` (if any), then for the chosen
        view ``score`` and ``contrib__<layer>``; with ``view=None`` every view
        gets ``score__<view>`` and ``contrib__<view>__<layer>``. It carries
        neither the per-constraint values nor their reasons; :meth:`verdicts`
        does.
        """
        if view is not None:
            if view not in self.contributions:
                raise NormError(f"unknown view {view!r}; available: {self.views}")
            extra = pd.concat([self.scores[view].rename("score"), self.contributions[view].add_prefix("contrib__")], axis=1)
            return pd.concat([self.cases, extra], axis=1)
        parts: list[pd.Series | pd.DataFrame] = []
        for v in self.views:
            parts.append(self.scores[v].rename(f"score__{v}"))
            parts.append(self.contributions[v].add_prefix(f"contrib__{v}__"))
        return pd.concat([self.cases, *parts], axis=1) if parts else self.cases.copy()

    def verdicts(self) -> pd.DataFrame:
        """Long table of every case and constraint: the value, the scope and the reason.

        Index ``(<case id>, "constraint")`` in case order, then constraint
        order; columns ``value`` (``ν_c(σ)``, NaN without a value),
        ``in_scope`` (as :attr:`in_scope`) and ``reason`` (as :attr:`reasons`,
        a categorical over the codes of :mod:`wise.family`), so a table
        written from it still tells why a case has no value. Raises
        :class:`~wise.errors.NotScoredError` for a result without reasons.
        """
        if self.reasons is None:
            raise NotScoredError("this result carries no reasons (it was built without reasons=); score the log again")
        V = self.violations
        index = pd.MultiIndex.from_product([V.index, V.columns], names=[V.index.name, "constraint"])
        codes = self.reasons.reindex(index=V.index, columns=V.columns).astype(str).to_numpy().ravel()
        categories = list(dict.fromkeys([*REASONS, *codes]))
        return pd.DataFrame(
            {
                "value": V.to_numpy(dtype=float).ravel(),
                "in_scope": self.in_scope.reindex(index=V.index, columns=V.columns).to_numpy(dtype=bool).ravel(),
                "reason": pd.Categorical(codes, categories=categories),
            },
            index=index,
        )

    def summary(self) -> pd.DataFrame:
        """Per view: scored cases, mean score ``μ̄^(p)``, mean layer contributions
        (no reasons; :meth:`verdicts` has them per case and constraint)."""
        rows = []
        for v in self.views:
            s = self.scores[v]
            row: dict[str, Any] = {"view": v, "n_scored": int(s.notna().sum()), "mean_score": float(s.mean())}
            for layer in self.norm.layer_ids:
                row[f"contrib__{layer}"] = float(self.contributions[v][layer][s.notna()].mean())
            rows.append(row)
        return pd.DataFrame(rows).set_index("view")

    def applicability_density(self, scope: bool = False) -> float:
        """Average share of constraints per case that were evaluated
        (``scope=False``, default) or that are in scope (``scope=True``)."""
        m = self.in_scope if scope else self.applicable
        return float(m.mean(axis=1).mean()) if len(m) else float("nan")

    def check_decomposition(self, atol: float = 1e-9) -> float:
        """Max |Σ_λ Δ_λ − (1 − S)| over scored cases; raises if above ``atol``."""
        worst = 0.0
        for v in self.views:
            s = self.scores[v]
            lhs = self.contributions[v].sum(axis=1)[s.notna()]
            rhs = (1.0 - s)[s.notna()]
            worst = max(worst, float((lhs - rhs).abs().max()) if len(lhs) else 0.0)
        if worst > atol:
            raise AssertionError(f"layer decomposition violated: max error {worst:.3e}")
        return worst

    def worst_cases(self, view: str, n: int = 20, where: dict[str, Any] | pd.Series | None = None) -> pd.DataFrame:
        """The ``n`` lowest-scoring cases (optionally within a slice) with their
        layer contributions.

        ``where`` is a filter of :func:`wise.selection.select_cases`: ``{attribute:
        value}`` (equality) or ``{attribute: [values]}`` (membership), the case id
        allowed under the name of the case index, a rule of the selection
        grammar, or a boolean mask over cases. Like :meth:`frame` it carries no
        reasons; :meth:`verdicts` does."""
        f = self.frame(view)
        mask = select_cases(self.cases, where, log=self.log)
        f = f[mask & f["score"].notna()]
        return f.sort_values("score", kind="mergesort").head(n)

    def trace(self, case_id: Any) -> pd.DataFrame:
        """Events of one case (requires the log to be attached)."""
        if self.log is None:
            raise NotScoredError("no event log attached to this result")
        return self.log.trace(case_id)


def _effective_weights(M: np.ndarray, w: np.ndarray, norm: Norm, mode: str) -> np.ndarray:
    if mode == "flat":
        w_app = M @ w
        with np.errstate(divide="ignore", invalid="ignore"):
            return np.where(w_app[:, None] > 0, M * w[None, :] / w_app[:, None], np.nan)
    return _layer_balanced_weights(M, w, norm)


def _layer_balanced_weights(M: np.ndarray, w: np.ndarray, norm: Norm) -> np.ndarray:
    n = M.shape[0]
    cids = norm.constraint_ids
    layer_of = norm.layer_of
    w_eff = np.zeros_like(M)
    a_app = np.zeros(n)
    for layer in norm.layer_ids:
        idx = np.array([i for i, cid in enumerate(cids) if layer_of[cid] == layer], dtype=int)
        a = float(w[idx].sum()) if len(idx) else 0.0
        if len(idx) == 0 or a <= 0:
            continue
        b_app = M[:, idx] * w[idx][None, :]
        b_sum = b_app.sum(axis=1)
        layer_app = b_sum > 0
        with np.errstate(divide="ignore", invalid="ignore"):
            w_eff[:, idx] = np.where(b_sum[:, None] > 0, b_app / b_sum[:, None], 0.0) * a
        a_app += layer_app * a
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(a_app[:, None] > 0, w_eff / a_app[:, None], np.nan)


def _check_calibrations(recipes: Sequence[Recipe], semantics: Semantics) -> None:
    """Refuse a population-dependent recipe without a fitted record where the profile requires one."""
    if not semantics.fitted_calibration:
        return
    for r in recipes:
        if isinstance(r, QuantileScaleRecipe) and (r.calibration is None or not r.calibration.is_fitted):
            status = "no calibration record" if r.calibration is None else "an unfitted calibration record"
            raise NormError(
                f"derived attribute {r.name!r} (quantile_scale) has {status}; under the {semantics.name} semantics a "
                "population-dependent recipe is computed only with a fitted record (fit it with wise.fit_calibration)"
            )


def score(
    log: EventLog,
    norm: Norm,
    views: Sequence[str] | str | None = None,
    *,
    mode: str | None = None,
    derive: bool = True,
) -> ScoreResult:
    """Score every case of ``log`` against ``norm`` under one or more views.

    Parameters
    ----------
    views
        View names to score; default all views of the norm.
    mode
        ``"layer_balanced"`` or ``"flat"``; default ``norm.scoring_mode``.
    derive
        Compute the norm's ``derived_attributes`` for this run (see
        :func:`wise.derive.derived_log`); the result carries them in
        ``cases`` and ``log``. ``log`` itself is never changed. An attribute
        that :meth:`EventLog.derive` attached with the same recipe is reused;
        a recipe named like any other case attribute of ``log`` raises
        :class:`~wise.errors.NormError`. With ``derive=False`` the attributes
        must already be on ``log``. Under the corrected semantics (schema
        version 3) a ``quantile_scale`` recipe without a fitted calibration
        record is refused with :class:`~wise.errors.NormError`, with or
        without ``derive``.

    The norm is evaluated under its semantics profile, ``norm.semantics``.
    """
    views = [views] if isinstance(views, str) else list(dict.fromkeys(views or norm.view_names))
    for v in views:
        norm.get_view(v)
    mode = mode or norm.scoring_mode
    if mode not in SCORING_MODES:
        raise NormError(f"mode must be one of {SCORING_MODES}, got {mode!r}")
    calibrations: dict[str, Calibration] = {}
    _check_calibrations(norm.recipes, norm.semantics)
    if derive and norm.derived_attributes:
        scored, log = log, derived_log(log, norm.recipes)
        calibrations = realised_calibrations(scored, log, norm.recipes)

    V, S, R = _evaluate_norm(log, norm)
    M = V.notna().to_numpy(dtype=float)
    V0 = V.fillna(0.0).to_numpy(dtype=float)
    cids = list(V.columns)
    layer_ids = norm.layer_ids
    layer_of = norm.layer_of
    onehot = np.array([[1.0 if layer_of[cid] == layer else 0.0 for layer in layer_ids] for cid in cids])

    score_cols: list[np.ndarray] = []
    contributions: dict[str, pd.DataFrame] = {}
    weights: dict[str, np.ndarray] = {}
    for view in views:
        w = norm.weight_vector(view).to_numpy(dtype=float)
        weights[view] = w
        w_eff = _effective_weights(M, w, norm, mode)
        penalty_c = np.nan_to_num(w_eff) * V0
        unscored = np.all(np.isnan(w_eff), axis=1)
        s = 1.0 - penalty_c.sum(axis=1)
        s[unscored] = np.nan
        score_cols.append(s)
        contrib = penalty_c @ onehot
        contrib[unscored, :] = np.nan
        contributions[view] = pd.DataFrame(contrib, index=V.index, columns=layer_ids)

    scores = pd.DataFrame(np.column_stack(score_cols) if score_cols else np.empty((len(V), 0)), index=V.index, columns=views)
    return ScoreResult(
        norm=norm,
        cases=log.cases,
        violations=V,
        in_scope=S,
        scores=scores,
        contributions=contributions,
        mode=mode,
        log=log,
        norm_fingerprint=norm.fingerprint(),
        _weights=weights,
        calibrations=calibrations,
        reasons=R,
    )
